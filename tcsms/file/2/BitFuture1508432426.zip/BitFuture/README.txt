==LEGAL INFO==

This is a Mario fangame that I, Quillax (who can be contacted via "quinton@quintonland.com"), made without permission from the copyright owners, 
and is not affiliated with or endorsed by them.

Mario (who is mentioned in the game), related characters, the SMB3 boss theme, and SMB1-3 sound effects are owned and made by Nintendo. Mega Man 3's
Wily Stages 5-6 and ending theme, along with the NES Mega Man sound effects are owned by Capcom. Kirby's Adventure's Nightmare battle theme is owned by
HAL and Nintendo. The music and sound effects are ripped by various people, borrowed from "themushroomkingdom.net", "downloads.khinsider.com",
"blyka.legends-station.com", and "sounds-resource.com". Other elements, some of which are based off of existing copyrighted elements, are made by me.
You may feel free to use my creations, as long as recognition is provided.

Battle in the Future is not made for sale, and is therefore freeware. It is only made for fun. It is made with GameMaker: Studio, with graphics
made with MS Paint and GameMaker: Studio's built-in graphics editor.

==HOW DO I START IT?==

Hi there! Thanks for downloading Battle in the Future! To run it, simply run "BitFuture.exe" (you might want to make sure it's
extracted, though). It should be able to run very well on Windows (at least on 7 and onwards). It may not run correctly on very
old versions of Windows and platforms that aren't Windows. If it does run correctly on a platform that I stated was incompatible,
then please let me know.

If you are able to make it run correctly, then I hope you'll enjoy it!

==CONTROLS==

In-game (can be viewed through SHOW CONTROLS on the menu):

LEFT/RIGHT: Move
SHIFT: Jump (holding it will make you jump a bit higher)
CTRL: Pick up a harmless stationary object (if you're near it)/throw the object
ENTER: Pause/unpause the game

Menus (can be viewed while in the menus):

UP/DOWN: Select
ENTER/SHIFT: Confirm selection

==SPECIAL THANKS TO...==

*My mother (for proofreading the game's story, ending text, and README.TXT)
*My uncle (for proofreading part of README.TXT and giving a few suggestions)
*VinnyVideo (for beta-testing the game and providing helpful feedback)
*SonicZetrex (for also beta-testing the game and giving nice feedback)